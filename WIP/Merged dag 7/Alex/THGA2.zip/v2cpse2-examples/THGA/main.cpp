#include <iostream>
#include "Statemachine.hpp"

int main() {
	Statemachine state;
	state.machine();
	
}